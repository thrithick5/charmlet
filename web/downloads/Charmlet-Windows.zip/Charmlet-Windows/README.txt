Charmlet - Windows Edition
====================================

Welcome to Charmlet for Windows!

HOW TO RUN:
-----------
Option 1 (Recommended):
  Double-click "Launch.vbs".
  Your charm will open smoothly in its own desktop window.

Option 2:
  Double-click "run.bat".
  This launches the charm using Microsoft Edge or Chrome in app-window mode.

Option 3 (In Any Browser):
  Open "web\index.html" or "web\charm.html" directly in any browser.
  You can click the 3 dots in Edge or Chrome -> "Apps" -> "Install this site as an app"
  to pin it directly to your Windows Taskbar and Start Menu!

FEATURES:
---------
- 20 interactive talismans & charms from world traditions
- Real rope and bead physics
- Sway with cursor interaction and ritual animations
- 100% offline, private, zero data collection, no account needed.

Enjoy!
